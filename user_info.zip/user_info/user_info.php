<?php

 /*
 
    *  Plugin Name: User Info
    * Plugin URI: https://www.google.com
    * Description: The  first plugin that I have created. use 'myUserInfo ' shortcode for showing table like ['myUserInfo'].
    * Version: 1.0
    * Author: Gurjeet Singh
    * Author URI: http://www.thedevbrothers.com

 */
 

defined('ABSPATH') ||  die("Nice Try!");

//echo plugin_dir_path(__FILE__).'inc/script_enqueue.php';
//die();


/*---------------------------------------------------------------------------*/
/*             create database table on activation and deactivation !        */
/*---------------------------------------------------------------------------*/

        
    include plugin_dir_path(__FILE__).'inc/script_enqueue.php';
    include plugin_dir_path(__FILE__).'inc/user_infodb.php';   
    include plugin_dir_path(__FILE__).'inc/userinfo_shortcode.php';



    register_activation_hook(__FILE__, 'createUserInfo_table' );
    

    register_deactivation_hook(__FILE__, 'deleteUserInfo_table' );  
     
 



 
/*--------------------------------------------*/
/*              userInfo_admin_menu !        */
/*--------------------------------------------*/

 add_action( 'admin_menu', 'userInfo_admin_menu');


 function userInfo_admin_menu(){

add_menu_page( 'USER INFO', 'USER INFO', 'manage_options', 'user_info_form', 'user_info_menu_function', $icon_url = '', $position= null );

add_submenu_page( 'user_info_form', 'Add info', 'Add info' ,'manage_options', 'add_info', 'user_info_submenu_function' );
 }

function user_info_menu_function(){

    ?>

   

    <div class="col-12">

                <div class="row">

                <div class="card col-12">

                    <div class="card-header text-center bg-dark"> 
                        
                        <h2 class="text-white text-uppercase">All User Info</h2>
                        
                    </div>
                    <div class="card-body">
                    <table class="table table-responsive">
                        <thead class="text-uppercase">
                            <tr>
                            <th scope="col">Srno</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Country</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Hobbies</th>
                            <th scope="col">Profile Image</th>
                            <th scope="col">Created at</th>
                            </tr>
                        </thead>


                        <tbody>

                        <?php
                                global $wpdb;
                                $userinfo_tableName=$wpdb->prefix.'user_info';
                                $result = $wpdb->get_results ( "SELECT * FROM $userinfo_tableName" );
                                // echo"<pre>";
                                // print_r($result);
                                // echo"</pre>";

                                $count=1;

                                foreach ( $result as $userData ) {
                                    
                                    ?>
                                     <tr>
                                        <th scope="row"><?php echo $count;?> </th>
                                        <td><?php echo $userData->name;?></td>
                                        <td><?php echo $userData->email;?></td>
                                        <td><?php echo $userData->phone;?></td>
                                        <td><?php echo $userData->country;?></td>
                                        <td><?php echo $userData->gender;?></td>
                                        <td><?php echo $userData->hobbies;?></td>
                                        <td><?php echo $userData->profile_img;?></td>
                                        <td><?php echo $userData->create_at;?></td>
                                        
                                    </tr>

                                        
                                        
                                        
                                        
                                    <?php 
                                     
                                     $count++;
                                    }

                              
                        ?>
                             
                        </tbody>
                        </table>
                    </div>
                    </div>



                
                </div>


    </div>

   



<?php 
}


function user_info_submenu_function(){

    ?>

<div class="col-12">

<div class="row">

<div class="card col-10 m-auto">
    
    <div class="card-header text-center bg-dark"> 
           <h2 class="text-white text-uppercase">Add User Info</h2>
    </div>

    <div class="card-body w-75 m-auto">

            <!-- add form --> 

            <form  method="POST"  enctype="multipart/form-data" >


                <div class="form-group">
                    <label for="user_name">Name</label>
                    <input type="text" class="form-control" id="userName" name="userName"   placeholder="Enter Ypur Name " required>
                </div>

                <div class="form-group">
                    <label for="user_email">Email</label>
                    <input type="email" class="form-control" id="userEmail" name="userEmail" placeholder="Enter Your Email" required>
                </div>
                <div class="form-group">
                    <label for="user_password">Password</label>
                    <input type="password" class="form-control" id="userPswd" name="userPswd" placeholder="Enter Your Password" required>
                </div>

                <div class="form-group">
                    <label for="user_name">Phone</label>
                    <input type="text" class="form-control" id="userName" name="userPhone"   placeholder="Enter Ypur Name " required>
                </div>


                <div class="form-group">
                        <label for="user_country">Select Your Country </label>
                        <select class="form-control" id="user_country" name="userCountry">
                            <option value="india">India</option>
                            <option value="canada">Canada</option>
                            <option value ="australia">Australia</option>
                            <option value="usa">U.S.A</option>
                          
                        </select>
                </div>

               

                <div class="form-group">
              
                <label for="user_hobbies">Hobbies</label><br>
                <div class="form-check-inline">
               
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="userHobbies[]" value="Cricket">Cricket
                    </label>
                    </div>
                    <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input"name="userHobbies[]"  value="Singing">Singing
                    </label>
                    </div>
                    <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="userHobbies[]" value="TV">TV
                    </label>
                    </div>
                 </div>

                <div class="form-group">

                <label for="user_gender">Gender</label>
                <br>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="userGender" value="Male">Male
                    </label>
                    </div>
                    <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="userGender" value="Female">Female
                    </label>
                    </div>
                     
                </div>


                <div class="form-group">
                    <label for="user-profile-image">Profile Image</label>
                    <input type="file" class="form-control-file" id="userProfileImg" name="userProfileImg">
                </div> 
                
                <button type="submit" class="btn btn-primary" name="saveUserInfo">Submit</button>
                </form>



    </div>
    </div>




</div>


</div>
    
    
    
    <?php
}




 
/*--------------------------------------------*/
/*    InsertData into userinfo Table !        */
/*--------------------------------------------*/


 

    global $wpdb;
    $userinfo_tableName=$wpdb->prefix.'user_info';
    
    if ( isset( $_POST['saveUserInfo'] )){


   // echo "<pre>";

 



//  $userHobbies = $_POST['userHobbies'];

   
// $userHobbies = implode(", ", $userHobbies);
// echo $userHobbies;


// die("test");


 

    $userName = $_POST['userName'];

    $userEmail = $_POST['userEmail'];
    $userPswd = $_POST['userPswd'];
    $userPhone = $_POST['userPhone'];
    $userCountry = $_POST['userCountry'];
    $userGender = $_POST['userGender'];
    $userProfileImg=$_FILES['userProfileImg'];






    $userHobbies = $_POST['userHobbies'];

    $userHobbies = implode(", ", $userHobbies);

    


           

            // if ( ! function_exists( 'wp_handle_upload' ) ) {
            //     require_once( ABSPATH . 'wp-admin/includes/file.php' );
            // }

            // $uploadedfile = $_FILES['userProfileImg'];


            // $uploaded_overrides = array('test_form'=> false);

            // $movefile = wp_handle_upload( $uploadedfile, $uploaded_overrides);


            // if($movefile && !isset($movefile['error'])){


                // echo "<pre>";

                // echo $movefile['url'];
                
                // echo "</pre>";

                
                // echo '<a href="'.$movefile['url'].'"> view</a>';


                $wpdb->insert( $userinfo_tableName, 
                array(

                    'name' => $userName,
                    'email' => $userEmail,
                    'password' => $userPswd,
                    'phone' => $userPhone,
                    'country' => $userCountry,
                    'gender' => $userGender ,
                    'hobbies' => $userHobbies,
                    'profile_img'=>$userProfileImg['name']
                    
                ),

                    array( 
                        
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',                            
                            '%s'
                            )
        
    );






             }




 
    


       

  
 





 






?>