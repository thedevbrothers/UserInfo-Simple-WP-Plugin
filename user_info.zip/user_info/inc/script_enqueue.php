<?php 

/*--------------------------------------------*/
/*              userInfo_load_scripts!        */
/*--------------------------------------------*/


 
add_action('admin_enqueue_scripts', 'userInfo_load_scripts');
add_action('wp_enqueue_scripts', 'userInfo_load_scripts');


function userInfo_load_scripts() {

    wp_enqueue_style ( 'myuserInfo_css' , plugin_dir_url( __FILE__ ).'assets/css/style.css');  
    wp_enqueue_style ( 'bs4' , 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css');  
    wp_enqueue_script( 'custom_js', plugin_dir_url( __FILE__ ).'assets/js/custom.js', array() , '1.0.0' , true);  
    wp_enqueue_script( 'custom_js', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js', array() , '1.0.0' , false);      
    
}

 



?>