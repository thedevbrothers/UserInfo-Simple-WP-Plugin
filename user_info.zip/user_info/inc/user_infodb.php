<?php
    
function createUserInfo_table(){

    global $wpdb;


    $userinfo_tableName=$wpdb->prefix.'user_info';



    $userinfo_CreateTableQuery="CREATE TABLE  $userinfo_tableName  ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(200) NOT NULL , `email` VARCHAR(200) NOT NULL , `password` VARCHAR(200) NOT NULL , `phone`  VARCHAR(200) NOT NULL , `country` VARCHAR(200) NOT NULL , `gender` VARCHAR(200) NOT NULL , `hobbies` VARCHAR(200) NOT NULL , `profile_img` VARCHAR(200) NOT NULL , `create_at` TIMESTAMP NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB";



    require_once(ABSPATH."wp-admin/includes/upgrade.php");


    dbDelta( $userinfo_CreateTableQuery );

}



function deleteUserInfo_table(){

    global $wpdb;


    $userinfo_tableName=$wpdb->prefix.'user_info';



    $userinfo_DeleteTableQuery="DROP TABLE $userinfo_tableName;";

    $wpdb->query("DROP TABLE IF Exists $userinfo_tableName");



   // require_once(ABSPATH."wp-admin/includes/upgrade.php");


    //dbDelta( $userinfo_DeleteTableQuery );

}


 
?>