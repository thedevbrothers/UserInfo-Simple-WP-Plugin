<?php 




/*--------------------------------------------*/
/*              myUserInfo_shortcode !        */
/*--------------------------------------------*/


 

 add_action( 'init', 'userInfo_init' );
  
 function userInfo_init(){

    add_shortcode( "myUserInfo", "myUserInfo_shortcode" );
    
}









 function myUserInfo_shortcode($atts){
     
      

     return show();

 


 


 }



 function show(){
    ?>
        
    <div class="col-12">

                <div class="row">

                <div class="card col-12">

                    <div class="card-header text-center bg-dark"> 
                        
                        <h2 class="text-white text-uppercase">All User Info</h2>
                        
                    </div>
                    <div class="card-body">
                    <table class="table table-responsive">
                        <thead class="text-uppercase">
                            <tr>
                            <th scope="col">Srno</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Country</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Hobbies</th>
                            <th scope="col">Profile Image</th>
                            <th scope="col">Created at</th>
                            </tr>
                        </thead>


                        <tbody>

                        <?php
                                global $wpdb;
                                $userinfo_tableName=$wpdb->prefix.'user_info';
                                $result = $wpdb->get_results ( "SELECT * FROM $userinfo_tableName" );
                                // echo"<pre>";
                                // print_r($result);
                                // echo"</pre>";

                                $count=1;

                                foreach ( $result as $userData ) {
                                    
                                    ?>
                                     <tr>
                                        <th scope="row"><?php echo $count;?> </th>
                                        <td><?php echo $userData->name;?></td>
                                        <td><?php echo $userData->email;?></td>
                                        <td><?php echo $userData->phone;?></td>
                                        <td><?php echo $userData->country;?></td>
                                        <td><?php echo $userData->gender;?></td>
                                        <td><?php echo $userData->hobbies;?></td>
                                        <td><?php echo $userData->profile_img;?></td>
                                        <td><?php echo $userData->create_at;?></td>
                                        
                                    </tr>

                                        
                                        
                                        
                                        
                                    <?php 
                                     
                                     $count++;
                                    }

                              
                        ?>
                             
                        </tbody>
                        </table>
                    </div>
                    </div>



                
                </div>


    </div>

   

    
    
    
    
    
    <?php

    
 }


 ?>